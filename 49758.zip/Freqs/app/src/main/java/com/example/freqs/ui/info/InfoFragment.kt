package com.example.freqs.ui.info

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.freqs.databinding.FragmentInfoBinding

// Classe InfoFragment que herda de Fragment
class InfoFragment : Fragment() {

    private var _binding: FragmentInfoBinding? = null // Binding para o fragmento
    private val binding get() = _binding!! // Propriedade para aceder ao binding

    // Método chamado quando a view é criada
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentInfoBinding.inflate(inflater, container, false) // Inflar o layout do fragmento
        val root: View = binding.root // Obter a root view do binding

        return root // Retornar a root view
    }

    // Método chamado quando a view é destruída
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Limpar o binding
    }
}