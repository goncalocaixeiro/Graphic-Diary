package com.example.freqs

import android.graphics.Bitmap

data class LocalPhoto(
    val id: Int,
    val localId: Int,
    val photo: Bitmap
)
