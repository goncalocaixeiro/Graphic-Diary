package com.example.freqs

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.freqs.databinding.ActivityLocalBinding
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.random.Random

// Classe LocalActivity que herda de AppCompatActivity
class LocalActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLocalBinding // Binding para a atividade
    private lateinit var dbHelper: DatabaseHelper // Helper para a base de dados
    private val PICK_IMAGE_REQUEST = 1 // Código de pedido para escolher imagem
    private var localId: Int = 0 // ID do local

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLocalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this) // Inicializar o helper da base de dados

        // Obter os extras do intent
        intent.extras?.let {
            localId = it.getInt("localId")
            val local = dbHelper.getLocation(localId)
            binding.tituloLocal.setText(local?.nome)
            binding.descricaoLocal.setText(local?.descricao)
            binding.dataLocal.text = local?.data
        }

        val images = dbHelper.getImagesByLocationId(localId)

        // Selecionar uma imagem aleatória da lista
        if (images.isNotEmpty()) {
            val randomImage = images[Random.nextInt(images.size)]
            binding.imagemfundoLocal.setImageBitmap(randomImage)
        } else {
            // Caso não sejam encontradas imagens
            binding.imagemfundoLocal.setImageResource(R.drawable.image_background)
        }

        // Configurar listeners para os diálogos de edição de título e descrição
        binding.tituloLocal.setOnClickListener {
            val titulo = binding.tituloLocal.text.toString()
            showEditTitleDialog(titulo, localId)
        }
        binding.descricaoLocal.setOnClickListener {
            val descricao = binding.descricaoLocal.text.toString()
            showEditDescDialog(descricao, localId)
        }

        binding.voltarLocal.setOnClickListener {
            finish()
        }

        binding.escolherImagem.setOnClickListener {
            openImageChooser()
        }
    }

    // Método chamado quando a atividade retorna um resultado
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri? = data.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
                val resizedBitmap = getResizedBitmap(bitmap, 1024)
                val result = dbHelper.insertImage(localId, resizedBitmap)
                if (result > 0) {
                    Toast.makeText(this, "Imagem inserida com sucesso", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Erro ao inserir imagem", Toast.LENGTH_SHORT).show()
                }
                binding.imagemfundoLocal.setImageBitmap(resizedBitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    // Mostrar diálogo para editar o título
    private fun showEditTitleDialog(currentTitle: String, idLocal: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Editar Título")

        val input = EditText(this)
        input.setText(currentTitle)
        builder.setView(input)

        builder.setPositiveButton("Guardar") { dialog, _ ->
            val newTitle = input.text.toString()
            binding.tituloLocal.text = newTitle
            val n = dbHelper.updateNome(idLocal, newTitle)
            if (n > 0) {
                Toast.makeText(this, "Título atualizado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Erro ao atualizar título", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    // Mostrar diálogo para editar a descrição
    private fun showEditDescDialog(currentDesc: String, idLocal: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Editar Descrição")

        val input = EditText(this)
        input.setText(currentDesc)
        builder.setView(input)

        builder.setPositiveButton("Guardar") { dialog, _ ->
            val newDesc = input.text.toString()
            binding.descricaoLocal.text = newDesc
            val n = dbHelper.updateDesc(idLocal, newDesc)
            if (n > 0) {
                Toast.makeText(this, "Descrição atualizada", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Erro ao atualizar a descrição", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }



    // Abrir seletor de imagens
    private fun openImageChooser() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    // Redimensionar Bitmap
    fun getResizedBitmap(image: Bitmap, maxSize: Int): Bitmap {
        var width = image.width
        var height = image.height

        val bitmapRatio = width.toFloat() / height.toFloat()
        if (bitmapRatio > 1) {
            width = maxSize
            height = (width / bitmapRatio).toInt()
        } else {
            height = maxSize
            width = (height * bitmapRatio).toInt()
        }
        return Bitmap.createScaledBitmap(image, width, height, true)
    }

    // Sobrescrever o método onBackPressed para não fazer nada
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
    }
}