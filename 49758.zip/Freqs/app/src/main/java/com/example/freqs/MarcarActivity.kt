package com.example.freqs

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.freqs.databinding.ActivityMarcarBinding

// Classe MarcarActivity que herda de AppCompatActivity
class MarcarActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMarcarBinding // Binding para a atividade

    // Método chamado quando a atividade é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMarcarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obter os extras do intent
        val userId = intent.getIntExtra("userId", 0)
        val latitude = intent.getDoubleExtra("latitude", 0.0)
        val longitude = intent.getDoubleExtra("longitude", 0.0)
        val idUser = intent.getIntExtra("userId", 0)

        // Configurar listener para o botão de marcar
        binding.marcar.setOnClickListener {
            val nome = binding.nome.text.toString()
            val descricao = binding.descricao.text.toString()

            // Verificar se os campos estão preenchidos
            if (nome.isEmpty() || descricao.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            } else {
                // Registar a localização e navegar para a MainActivity
                register(nome, descricao, latitude, longitude, idUser)
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra("navigateToHome", true)
                    putExtra("userIdMarcar", userId)
                }
                startActivity(intent)
            }
        }

        // Configurar listener para o botão de cancelar
        binding.cancelar.setOnClickListener {
            finish()
        }
    }

    // Método sobrescrito para desativar o botão de voltar
    override fun onBackPressed() {
    }

    // Método para registar a localização na base de dados
    fun register(nome: String, descricao: String, latitude: Double, longitude: Double, userId: Int) {
        val dbHelper = DatabaseHelper(this)
        val result = dbHelper.insertLocation(longitude, latitude, nome, descricao, userId)
        if (result > -1 && nome.isNotEmpty() && descricao.isNotEmpty()) {
            Toast.makeText(this, "Local marcado com sucesso", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Erro ao marcar local", Toast.LENGTH_SHORT).show()
        }
    }
}