package com.example.freqs

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Classe AdapterLocations que herda de RecyclerView.Adapter para gerir a lista de localizações
class AdapterLocations(
    private val locations: List<Localizacao>, // Lista de localizações
    val listener: (Int) -> Unit, // Função de callback para clique no item
    val deleteListener: (Int) -> Unit // Função de callback para clique longo no item
) : RecyclerView.Adapter<AdapterLocations.MyViewHolder>() {

    // Método chamado para criar uma nova ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        // Inflar o layout do item da lista
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.locais_adapter, parent, false)
        return MyViewHolder(itemView)
    }

    // Método chamado para obter o número de itens na lista
    override fun getItemCount() = locations.size

    // Método chamado para associar os dados do item à ViewHolder
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = locations[position]
        holder.data.text = currentItem.data // Definir a data do item
        holder.nome.text = currentItem.nome // Definir o nome do item

        // Definir o clique no item
        holder.itemView.setOnClickListener {
            listener(currentItem.id)
        }

        // Definir o clique longo no item
        holder.itemView.setOnLongClickListener {
            deleteListener(currentItem.id)
            true
        }
    }

    // Classe ViewHolder que representa o layout do item da lista
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val data = itemView.findViewById(R.id.dataAdapter) as TextView // TextView para a data
        val nome = itemView.findViewById(R.id.nomeLocal) as TextView // TextView para o nome
    }
}