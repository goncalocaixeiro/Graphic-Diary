package com.example.freqs.ui.locais

import android.app.AlertDialog
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.freqs.AdapterLocations
import com.example.freqs.DatabaseHelper
import com.example.freqs.LocalActivity
import com.example.freqs.MarcarActivity
import com.example.freqs.databinding.FragmentLocaisBinding

// Classe LocaisFragment que herda de Fragment
class LocaisFragment : Fragment() {

    private var _binding: FragmentLocaisBinding? = null // Binding para o fragmento
    private val binding get() = _binding!! // Propriedade para aceder ao binding
    private var dbHelper: DatabaseHelper? = null // Helper para a base de dados

    // Método chamado quando a view é criada
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        dbHelper = DatabaseHelper(requireContext()) // Inicializar o helper da base de dados

        _binding = FragmentLocaisBinding.inflate(inflater, container, false) // Inflar o layout do fragmento
        val root: View = binding.root // Obter a root view do binding

        // Obter o userId das SharedPreferences
        val sharedPreferences = context?.getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        val userId = sharedPreferences?.getInt("userId", 0)
        initRecyclerView(userId!!) // Inicializar o RecyclerView com o userId

        return root // Retornar a root view
    }

    // Método para inicializar o RecyclerView
    private fun initRecyclerView(userId: Int) {
        binding.recyclerLocais.layoutManager = LinearLayoutManager(context) // Definir o layout manager
        binding.recyclerLocais.setHasFixedSize(true) // Definir que o tamanho do RecyclerView é fixo
        binding.recyclerLocais.adapter = getLocais(userId)?.let { AdapterLocations(it, { localID ->

            // Intent para navegar para LocalActivity
            val intent = Intent(requireContext(), LocalActivity::class.java).apply {
                putExtra("localId", localID)
            }
            startActivity(intent)
        }, { locationId ->
            showDeleteLocationDialog(locationId) // Mostrar o diálogo de confirmação para eliminar a localização
        }) }
    }

    // Método para obter as localizações do utilizador
    private fun getLocais(idUser: Int) = dbHelper?.readLocation(idUser)

    // Método chamado quando a view é destruída
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Limpar o binding
    }

    // Método para mostrar o diálogo de confirmação para eliminar a localização
    private fun showDeleteLocationDialog(locationId: Int) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Eliminar Localização")
        builder.setMessage("Tem certeza de que deseja eliminar a localização atual?")
        builder.setPositiveButton("Sim") { dialog, _ ->

            deleteLocation(locationId) // Eliminar a localização
            dialog.dismiss()
        }
        builder.setNegativeButton("Não") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    // Método para eliminar a localização
    private fun deleteLocation(locationId: Int) {
        dbHelper?.deleteLocation(locationId) // Eliminar a localização da base de dados
        Toast.makeText(context, "Localização eliminada", Toast.LENGTH_SHORT).show()

        // Recarregar o RecyclerView com as localizações atualizadas
        val userId = context?.getSharedPreferences("MyAppPrefs", MODE_PRIVATE)?.getInt("userId", 0)
        initRecyclerView(userId!!)
    }
}