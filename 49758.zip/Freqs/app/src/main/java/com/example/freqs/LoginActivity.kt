package com.example.freqs

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.freqs.databinding.ActivityLoginBinding

// Classe LoginActivity que herda de AppCompatActivity
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding // Binding para a atividade
    private lateinit var dbHelper: DatabaseHelper // Helper para a base de dados
    private var user: User? = null // Variável para armazenar o utilizador

    // Método chamado quando a atividade é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this) // Inicializar o helper da base de dados

        // Configurar listener para o botão de login
        binding.loginButton.setOnClickListener {
            val email = binding.email.text.toString() // Obter o email do campo de texto
            val password = binding.password.text.toString() // Obter a palavra-passe do campo de texto
            if(email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            } else {
                login(email, password) // Chamar o método de login
            }
        }

        // Configurar listener para o botão de redirecionamento para o registo
        binding.redirectButton.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java)) // Iniciar a atividade de registo
        }
    }

    // Método para efetuar o login
    private fun login(email: String, password: String) {
        user = dbHelper.readUser(email, password) // Ler o utilizador da base de dados
        if (user != null) {
            Toast.makeText(this, "Login efetuado com sucesso", Toast.LENGTH_SHORT).show()

            // Criar um intent para iniciar a MainActivity
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("user", user) // Passar o utilizador como extra
            }

            startActivity(intent) // Iniciar a MainActivity

        } else {
            Toast.makeText(this, "Erro ao efetuar login", Toast.LENGTH_SHORT).show()
        }
    }
}