package com.example.freqs

import android.os.Parcel
import android.os.Parcelable

import java.io.Serializable
data class Localizacao(
    val id: Int,
    val lat: Double,
    val long: Double,
    val nome: String,
    val descricao: String,
    val data: String,
    val idUser: Int
) : Serializable


