package com.example.freqs

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// Classe DatabaseHelper que herda de SQLiteOpenHelper para gerir a base de dados
class DatabaseHelper (private val context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        // Constantes para o nome e versão da base de dados
        private const val DATABASE_NAME = "Users.db"
        private const val DATABASE_VERSION = 8

        // Constantes para os nomes das tabelas e colunas
        private const val TABLE_NAME = "Users"
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_EMAIL = "email"
        private const val COL_PASSWORD = "password"
        private const val COL_CC = "cc" // número do cartão de cidadão
        private const val COL_CCV = "ccv" // validade do cc
        private const val COL_dNasc = "dNasc" // data de nascimento

        private const val TABLE_LOCATION = "Location"
        private const val COL_ID_LOCATION = "id"
        private const val COL_LONG = "long"
        private const val COL_LAT = "lat"
        private const val COL_LOCAL = "nome"
        private const val COL_DESC = "descricao"
        private const val COL_DATA = "data"
        private const val COL_ID_USER_LOCATION = "userid"

        private const val TABLE_IMAGE = "Image"
        private const val COL_ID_IMAGE = "id_image"
        private const val COL_IMAGE = "image"
        private const val COL_ID_LOCATION_IMAGE = "id_location"
    }

    // Método chamado quando a base de dados é criada pela primeira vez
    override fun onCreate(db: SQLiteDatabase?) {
        // Query para criar a tabela de utilizadores
        val createTableQuery = ("CREATE TABLE $TABLE_NAME " +
                "($COL_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " $COL_NAME TEXT," +
                " $COL_EMAIL TEXT," +
                " $COL_PASSWORD TEXT," +
                " $COL_CC TEXT," +
                " $COL_CCV TEXT," +
                " $COL_dNasc TEXT)")

        // Query para criar a tabela de localizações
        val createTableQueryLocation = ("CREATE TABLE $TABLE_LOCATION " +
                "($COL_ID_LOCATION INTEGER PRIMARY KEY AUTOINCREMENT," +
                " $COL_LONG REAL," +
                " $COL_LAT REAL," +
                " $COL_DESC TEXT," +
                " $COL_LOCAL TEXT," +
                " $COL_DATA TEXT," +
                " $COL_ID_USER_LOCATION INTEGER)")

        // Query para criar a tabela de imagens
        val createTableQueryImage = ("CREATE TABLE $TABLE_IMAGE " +
                "($COL_ID_IMAGE INTEGER PRIMARY KEY AUTOINCREMENT," +
                " $COL_IMAGE BLOB," +
                " $COL_ID_LOCATION_IMAGE INTEGER)")

        // Executar as queries para criar as tabelas
        db?.execSQL(createTableQueryLocation)
        db?.execSQL(createTableQuery)
        db?.execSQL(createTableQueryImage)
    }

    // Método chamado quando a base de dados é atualizada
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Queries para eliminar as tabelas existentes
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        val dropTableQueryLocation = "DROP TABLE IF EXISTS $TABLE_LOCATION"
        val dropTableQueryImage = "DROP TABLE IF EXISTS $TABLE_IMAGE"

        // Executar as queries para eliminar as tabelas
        db?.execSQL(dropTableQuery)
        db?.execSQL(dropTableQueryLocation)
        db?.execSQL(dropTableQueryImage)

        // Chamar o método onCreate para recriar as tabelas
        onCreate(db)
    }

    // Método para inserir dados na tabela de utilizadores
    fun insertData(
        nome: String,
        email: String,
        password: String,
        cc: String,
        ccv: String,
        dNasc: String
    ): Long {
        // Criar um ContentValues para armazenar os valores a serem inseridos
        val values = ContentValues().apply {
            put(COL_NAME, nome)
            put(COL_EMAIL, email)
            put(COL_PASSWORD, password)
            put(COL_CC, cc)
            put(COL_CCV, ccv)
            put(COL_dNasc, dNasc)
        }

        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Inserir os valores na tabela e retornar o ID da linha inserida
        return db.insert(TABLE_NAME, null, values)
    }

    // Método para ler um utilizador da tabela de utilizadores
    fun readUser(email: String, password: String): User? {
        // Obter a base de dados em modo de leitura
        val db = readableDatabase

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_EMAIL = ? AND $COL_PASSWORD = ?"
        val selectionArgs = arrayOf(email, password)

        // Executar a query para obter o cursor
        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)

        var user: User? = null
        if (cursor.moveToFirst()) {
            // Obter os valores das colunas e criar um objeto User
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME))
            val cc = cursor.getString(cursor.getColumnIndexOrThrow(COL_CC))
            val ccv = cursor.getString(cursor.getColumnIndexOrThrow(COL_CCV))
            val dNasc = cursor.getString(cursor.getColumnIndexOrThrow(COL_dNasc))
            user = User(id, name, email, password, cc, ccv, dNasc)
        }

        // Fechar o cursor
        cursor.close()
        return user
    }

    // Método para inserir uma localização na tabela de localizações
    fun insertLocation(long: Double, lat: Double, local: String, desc: String, idUser: Int): Long {
        // Obter a data atual formatada
        val currentDate = Calendar.getInstance().time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val formattedDate = dateFormat.format(currentDate)

        // Criar um ContentValues para armazenar os valores a serem inseridos
        val values = ContentValues().apply {
            put(COL_LONG, long)
            put(COL_LAT, lat)
            put(COL_LOCAL, local)
            put(COL_DESC, desc)
            put(COL_DATA, formattedDate)
            put(COL_ID_USER_LOCATION, idUser)
        }

        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Inserir os valores na tabela e retornar o ID da linha inserida
        return db.insert(TABLE_LOCATION, null, values)
    }

    // Método para ler localizações da tabela de localizações
    fun readLocation(idUser: Int): List<Localizacao> {
        // Obter a base de dados em modo de leitura
        val db = readableDatabase

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_USER_LOCATION = ?"
        val selectionArgs = arrayOf(idUser.toString())

        // Executar a query para obter o cursor
        val cursor = db.query(TABLE_LOCATION, null, selection, selectionArgs, null, null, null)
        val locations = mutableListOf<Localizacao>()

        // Iterar sobre o cursor e adicionar as localizações à lista
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID_LOCATION))
            val lat = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LAT))
            val long = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LONG))
            val local = cursor.getString(cursor.getColumnIndexOrThrow(COL_LOCAL))
            val desc = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESC))
            val data = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATA))
            val idUser = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID_USER_LOCATION))
            locations.add(Localizacao(id, lat, long, local, desc, data, idUser))
        }

        // Fechar o cursor
        cursor.close()
        return locations
    }

    // Método para eliminar uma localização da tabela de localizações
    fun deleteLocation(id: Int): Int {
        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_LOCATION = ?"
        val selectionArgs = arrayOf(id.toString())

        // Eliminar a localização e retornar o número de linhas afetadas
        return db.delete(TABLE_LOCATION, selection, selectionArgs)
    }

    // Método para obter uma localização pelo ID
    fun getLocation(idLocation: Int): Localizacao? {
        // Obter a base de dados em modo de leitura
        val db = readableDatabase

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_LOCATION = ?"
        val selectionArgs = arrayOf(idLocation.toString())

        // Executar a query para obter o cursor
        val cursor = db.query(TABLE_LOCATION, null, selection, selectionArgs, null, null, null)
        var location: Localizacao? = null

        if (cursor.moveToFirst()) {
            // Obter os valores das colunas e criar um objeto Localizacao
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID_LOCATION))
            val lat = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LAT))
            val long = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LONG))
            val local = cursor.getString(cursor.getColumnIndexOrThrow(COL_LOCAL))
            val desc = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESC))
            val data = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATA))
            val idUser = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID_USER_LOCATION))
            location = Localizacao(id, lat, long, local, desc, data, idUser)
        }

        // Fechar o cursor
        cursor.close()
        return location
    }

    // Método para atualizar o nome de uma localização
    fun updateNome(id: Int, nome: String): Int {
        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Criar um ContentValues para armazenar o novo valor
        val values = ContentValues().apply {
            put(COL_LOCAL, nome)
        }

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_LOCATION = ?"
        val selectionArgs = arrayOf(id.toString())

        // Atualizar a localização e retornar o número de linhas afetadas
        return db.update(TABLE_LOCATION, values, selection, selectionArgs)
    }

    // Método para atualizar a descrição de uma localização
    fun updateDesc(id: Int, desc: String): Int {
        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Criar um ContentValues para armazenar o novo valor
        val values = ContentValues().apply {
            put(COL_DESC, desc)
        }

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_LOCATION = ?"
        val selectionArgs = arrayOf(id.toString())

        // Atualizar a localização e retornar o número de linhas afetadas
        return db.update(TABLE_LOCATION, values, selection, selectionArgs)
    }

    // Método para inserir uma imagem na tabela de imagens
    fun insertImage(idLocal: Int, image: Bitmap): Long {
        // Converter a imagem para um array de bytes
        val outputStream = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        val imageBytes = outputStream.toByteArray()

        // Criar um ContentValues para armazenar os valores a serem inseridos
        val values = ContentValues().apply {
            put(COL_ID_LOCATION_IMAGE, idLocal)
            put(COL_IMAGE, imageBytes)
        }

        // Obter a base de dados em modo de escrita
        val db = writableDatabase

        // Inserir os valores na tabela e retornar o ID da linha inserida
        return db.insert(TABLE_IMAGE, null, values)
    }

    // Método para obter imagens pelo ID da localização
    fun getImagesByLocationId(idLocal: Int): List<Bitmap> {
        // Obter a base de dados em modo de leitura
        val db = readableDatabase

        // Definir a seleção e os argumentos de seleção
        val selection = "$COL_ID_LOCATION_IMAGE = ?"
        val selectionArgs = arrayOf(idLocal.toString())

        // Executar a query para obter o cursor
        val cursor = db.query(TABLE_IMAGE, arrayOf(COL_IMAGE), selection, selectionArgs, null, null, null)
        val images = mutableListOf<Bitmap>()

        // Iterar sobre o cursor e adicionar as imagens à lista
        while (cursor.moveToNext()) {
            val imageBytes = cursor.getBlob(cursor.getColumnIndexOrThrow(COL_IMAGE))
            val image = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
            images.add(image)
        }

        // Fechar o cursor
        cursor.close()
        return images
    }
}