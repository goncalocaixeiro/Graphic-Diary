package com.example.freqs

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.freqs.databinding.ActivityRegisterBinding
import java.util.Calendar

// Classe RegisterActivity que herda de AppCompatActivity
class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding // Binding para a atividade
    private lateinit var dbHelper: DatabaseHelper // Helper para a base de dados

    // Método chamado quando a atividade é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this) // Inicializar o helper da base de dados

        // Configurar listener para o campo de data de nascimento
        binding.dNasc.setOnClickListener {
            showDatePickerDialog(binding.dNasc)
        }

        // Configurar listener para o campo de validade do cartão de crédito
        binding.ccv.setOnClickListener {
            showDatePickerDialog(binding.ccv)
        }

        // Configurar listener para o botão de registo
        binding.signupButton.setOnClickListener {
            val nome = binding.nome.text.toString() // Obter o nome do campo de texto
            val email = binding.email.text.toString() // Obter o email do campo de texto
            val password = binding.password.text.toString() // Obter a palavra-passe do campo de texto
            val passwordConfirm = binding.confirmPassword.text.toString() // Obter a confirmação da palavra-passe
            val cc = binding.cc.text.toString() // Obter o número do cartão de crédito
            val ccv = binding.ccv.text.toString() // Obter a validade do cartão de crédito
            val dNasc = binding.dNasc.text.toString() // Obter a data de nascimento

            // Chamar o método de registo
            register(nome, email, password, passwordConfirm, cc, ccv, dNasc)
        }
    }

    // Método para mostrar o DatePickerDialog
    private fun showDatePickerDialog(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                editText.setText(selectedDate)
            },
            year, month, day
        )
        datePickerDialog.show()
    }

    // Método para registar o utilizador
    private fun register(nome: String, email: String, password: String, confirmPass: String, cc: String, ccv: String, dNasc: String) {
        // Verificar se o número do cartão de crédito tem 8 dígitos
        if (cc.length != 8) {
            Toast.makeText(this, "O cartão de crédito deve ter 8 dígitos", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar se o nome tem pelo menos 3 caracteres
        if (nome.length < 3) {
            Toast.makeText(this, "O nome deve ter pelo menos 3 caracteres", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar se a palavra-passe tem pelo menos 6 caracteres
        if (password.length < 6) {
            Toast.makeText(this, "A senha deve ter pelo menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar se o email tem um formato válido
        if (!isValidEmail(email)) {
            Toast.makeText(this, "Formato de email inválido", Toast.LENGTH_SHORT).show()
            return
        }

        // Inserir os dados na base de dados
        val result = dbHelper.insertData(nome, email, password, cc, ccv, dNasc)
        if (result > -1 && nome.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && cc.isNotEmpty() && ccv.isNotEmpty() && dNasc.isNotEmpty() && password == confirmPass) {
            Toast.makeText(this, "Registo efetuado com sucesso", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        } else {
            if (password != confirmPass) {
                Toast.makeText(this, "As passwords não coincidem", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Erro ao registar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Método para verificar se o email tem um formato válido
    fun isValidEmail(email: String): Boolean {
        val emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$".toRegex()
        return email.matches(emailRegex)
    }
}