package com.example.freqs

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.navigation.ui.NavigationUI
import com.example.freqs.R
import com.example.freqs.User
import com.example.freqs.databinding.ActivityMainBinding
import com.example.freqs.ui.home.HomeFragment
import com.example.freqs.ui.locais.LocaisFragment

// Classe MainActivity que herda de AppCompatActivity
class MainActivity : AppCompatActivity(){

    private lateinit var appBarConfiguration: AppBarConfiguration // Configuração da AppBar
    private lateinit var binding: ActivityMainBinding // Binding para a atividade

    // Método chamado quando a atividade é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obter o utilizador passado pelo intent
        val user = intent.getSerializableExtra("user") as? User
        var userId = user?.id ?: 0

        // Verificar se deve navegar para a Home
        if (intent.getBooleanExtra("navigateToHome", false)) {
            userId = intent.getIntExtra("userIdMarcar", 0)
        }

        // Configurar o NavController e o bundle com o userId
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        val bundle = Bundle().apply {
            putInt("userId", userId)
        }

        // Guardar o userId nas SharedPreferences
        val sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("userId", userId)
        editor.apply()

        // Navegar para o fragmento Home com o bundle
        navController.navigate(R.id.nav_home, bundle)

        // Configurar a toolbar
        setSupportActionBar(binding.appBarMain.toolbar)

        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView

        // Configurar a AppBarConfiguration com os destinos principais
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_locais, R.id.nav_info, R.id.nav_logout
            ), drawerLayout
        )

        // Configurar a ActionBar com o NavController
        setupActionBarWithNavController(navController, appBarConfiguration)

        // Configurar o NavigationView com o NavController
        navView.setupWithNavController(navController)

        // Configurar o listener para os itens do menu de navegação
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_logout -> {
                    logout() // Chamar o método de logout
                    true
                }
                else -> {
                    val handled = NavigationUI.onNavDestinationSelected(menuItem, navController)
                    if (handled) {
                        drawerLayout.closeDrawer(GravityCompat.START)
                    }
                    handled
                }
            }
        }
    }

    // Método sobrescrito para desativar o botão de voltar
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
    }

    // Método para suportar a navegação para cima
    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    // Método para efetuar o logout
    private fun logout() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
}