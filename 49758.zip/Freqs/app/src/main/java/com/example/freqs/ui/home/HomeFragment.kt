package com.example.freqs.ui.home

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.example.freqs.R
import com.example.freqs.databinding.FragmentHomeBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import androidx.navigation.fragment.navArgs
import com.example.freqs.DatabaseHelper
import com.example.freqs.MarcarActivity

// Classe HomeFragment que herda de Fragment e implementa OnMapReadyCallback, GoogleMap.OnMarkerClickListener e GoogleMap.OnMapClickListener
class HomeFragment : Fragment(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMapClickListener {

    private var _binding: FragmentHomeBinding? = null // Binding para o fragmento
    private val binding get() = _binding!!
    private lateinit var map: GoogleMap // Mapa do Google
    private lateinit var fusedLocationClient: FusedLocationProviderClient // Cliente para obter a localização
    private val markerCoordinates = mutableListOf<LatLng>() // Lista de coordenadas dos marcadores
    private val args: HomeFragmentArgs by navArgs() // Argumentos de navegação

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1 // Código de pedido de permissão de localização
    }

    // Método chamado quando a view é criada
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val mapFragment = childFragmentManager.findFragmentById(R.id.map_fragment) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        // Verificar se a permissão de localização foi concedida
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE)
        }

        val userId = args.userId

        return root
    }

    // Método chamado quando a view é destruída
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Método chamado quando o mapa está pronto
    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true
        map.setOnMarkerClickListener(this)
        map.setOnMapClickListener(this)
        setUpMap()
    }

    // Configurar o mapa
    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE)
            return
        }
        map.isMyLocationEnabled = true
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val currentLatLng = LatLng(location.latitude, location.longitude)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f))
            } else {
                val defaultLocation = LatLng(-23.5505, -46.6333)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12f))
            }

            getAllMarkers()
        }
    }

    // Colocar um marcador no mapa
    private fun placeMarkerOnMap(location: LatLng, title: String) {
        val markerOptions = MarkerOptions().position(location)
        markerOptions.title(title)
        map.addMarker(markerOptions)
    }

    // Método chamado quando um marcador é clicado
    override fun onMarkerClick(p0: Marker) = false

    // Método chamado quando o mapa é clicado
    override fun onMapClick(latLng: LatLng) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Deseja adicionar um marcador aqui?")
            .setCancelable(false)
            .setPositiveButton("Sim") { dialog, id ->
                val intent = Intent(requireContext(), MarcarActivity::class.java).apply {
                    putExtra("latitude", latLng.latitude)
                    putExtra("longitude", latLng.longitude)
                    putExtra("userId", args.userId)
                }
                startActivity(intent)
            }
            .setNegativeButton("Não") { dialog, id ->
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    // Obter todos os marcadores
    private fun getAllMarkers() {
        clearMarkers()
        val userId = args.userId
        val dbHelper = DatabaseHelper(requireContext())
        val locations = dbHelper.readLocation(userId)

        locations.forEach {
            val location = LatLng(it.lat, it.long)
            val title = it.descricao
            placeMarkerOnMap(location, title)
        }
    }

    // Limpar todos os marcadores
    private fun clearMarkers() {
        map.clear()
        markerCoordinates.clear()
    }
}