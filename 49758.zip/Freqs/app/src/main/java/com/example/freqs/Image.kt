package com.example.freqs

import android.graphics.Bitmap
import java.io.Serializable

data class Image(
    val id: Int,
    val idLocation: Int,
    val image: Bitmap? = null // Optional Bitmap field for the image
) : Serializable